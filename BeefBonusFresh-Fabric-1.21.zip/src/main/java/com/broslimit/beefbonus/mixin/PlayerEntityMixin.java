package com.broslimit.beefbonus.mixin;

import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.world.World;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(PlayerEntity.class)
public abstract class PlayerEntityMixin {
    @Inject(method = "eatFood", at = @At("HEAD"))
    private void beefbonus$bonusForSteak(World world, ItemStack stack,
            CallbackInfoReturnable<ItemStack> cir) {
        if (world.isClient || stack.isEmpty() || !stack.isOf(Items.COOKED_BEEF)) return;

        PlayerEntity player = (PlayerEntity) (Object) this;
        int roll = world.random.nextInt(10000);
        ItemStack reward;

        if (roll < 1800) { // 18% food
            Item[] items = {Items.COOKED_BEEF, Items.COOKED_PORKCHOP, Items.COOKED_CHICKEN,
                Items.COOKED_MUTTON, Items.COOKED_RABBIT, Items.COOKED_COD, Items.COOKED_SALMON,
                Items.BREAD, Items.BAKED_POTATO, Items.CARROT, Items.GOLDEN_CARROT,
                Items.APPLE, Items.GOLDEN_APPLE, Items.PUMPKIN_PIE, Items.COOKIE,
                Items.CAKE, Items.MELON_SLICE, Items.SWEET_BERRIES, Items.GLOW_BERRIES};
            reward = new ItemStack(items[world.random.nextInt(items.length)], 1 + world.random.nextInt(4));
        } else if (roll < 3100) { // 13% blocks and building materials
            Item[] items = {Items.IRON_BLOCK, Items.GOLD_BLOCK, Items.COPPER_BLOCK,
                Items.COAL_BLOCK, Items.AMETHYST_BLOCK, Items.QUARTZ_BLOCK,
                Items.OBSIDIAN, Items.CRYING_OBSIDIAN, Items.GLOWSTONE,
                Items.SEA_LANTERN, Items.PRISMARINE, Items.BRICKS,
                Items.GLASS, Items.TNT, Items.HONEY_BLOCK, Items.SLIME_BLOCK};
            reward = new ItemStack(items[world.random.nextInt(items.length)], 1 + world.random.nextInt(3));
        } else if (roll < 4500) { // 14% tools
            Item[] items = {Items.STONE_PICKAXE, Items.IRON_PICKAXE, Items.DIAMOND_PICKAXE,
                Items.IRON_AXE, Items.DIAMOND_AXE, Items.IRON_SHOVEL, Items.DIAMOND_SHOVEL,
                Items.IRON_HOE, Items.DIAMOND_HOE, Items.SHEARS, Items.FLINT_AND_STEEL,
                Items.FISHING_ROD, Items.CARROT_ON_A_STICK, Items.COMPASS, Items.CLOCK};
            reward = new ItemStack(items[world.random.nextInt(items.length)]);
        } else if (roll < 5600) { // 11% weapons
            Item[] items = {Items.STONE_SWORD, Items.IRON_SWORD, Items.DIAMOND_SWORD,
                Items.BOW, Items.CROSSBOW, Items.TRIDENT, Items.MACE, Items.SHIELD,
                Items.ARROW, Items.SPECTRAL_ARROW, Items.FIREWORK_ROCKET, Items.TNT};
            reward = new ItemStack(items[world.random.nextInt(items.length)], 1 + world.random.nextInt(3));
        } else if (roll < 6600) { // 10% armor
            Item[] items = {Items.CHAINMAIL_HELMET, Items.CHAINMAIL_CHESTPLATE,
                Items.IRON_HELMET, Items.IRON_CHESTPLATE, Items.IRON_LEGGINGS, Items.IRON_BOOTS,
                Items.DIAMOND_HELMET, Items.DIAMOND_CHESTPLATE, Items.DIAMOND_LEGGINGS,
                Items.DIAMOND_BOOTS, Items.TURTLE_HELMET, Items.ELYTRA, Items.WOLF_ARMOR};
            reward = new ItemStack(items[world.random.nextInt(items.length)]);
        } else if (roll < 7600) { // 10% resources
            Item[] items = {Items.IRON_INGOT, Items.GOLD_INGOT, Items.COPPER_INGOT,
                Items.EMERALD, Items.LAPIS_LAZULI, Items.REDSTONE, Items.DIAMOND,
                Items.AMETHYST_SHARD, Items.QUARTZ, Items.PRISMARINE_SHARD,
                Items.PRISMARINE_CRYSTALS, Items.BLAZE_ROD, Items.ENDER_PEARL,
                Items.STRING, Items.GUNPOWDER, Items.LEATHER, Items.RABBIT_HIDE};
            reward = new ItemStack(items[world.random.nextInt(items.length)], 1 + world.random.nextInt(4));
        } else if (roll < 8500) { // 9% utility/rare loot
            Item[] items = {Items.EXPERIENCE_BOTTLE, Items.NAME_TAG, Items.SADDLE,
                Items.LEAD, Items.TOTEM_OF_UNDYING, Items.HEART_OF_THE_SEA,
                Items.NAUTILUS_SHELL, Items.SHULKER_SHELL, Items.ENDER_CHEST,
                Items.ENCHANTING_TABLE, Items.ANVIL, Items.BEACON,
                Items.DIAMOND_HORSE_ARMOR, Items.GOLDEN_HORSE_ARMOR, Items.IRON_HORSE_ARMOR};
            reward = new ItemStack(items[world.random.nextInt(items.length)]);
        } else if (roll < 9400) { // 9% enchanted book / potion
            if (world.random.nextBoolean()) {
                reward = new ItemStack(Items.ENCHANTED_BOOK);
                addRandomEnchantment(world, reward);
            } else {
                Item[] items = {Items.POTION, Items.SPLASH_POTION, Items.LINGERING_POTION,
                    Items.HONEY_BOTTLE, Items.MILK_BUCKET};
                reward = new ItemStack(items[world.random.nextInt(items.length)]);
            }
        } else if (roll < 9750) { // 3.5% diamond-tier gear
            Item[] items = {Items.DIAMOND_SWORD, Items.DIAMOND_PICKAXE,
                Items.DIAMOND_CHESTPLATE, Items.DIAMOND_LEGGINGS, Items.DIAMOND_BOOTS};
            reward = new ItemStack(items[world.random.nextInt(items.length)]);
        } else if (roll < 9950) { // 2% netherite ingot
            reward = new ItemStack(Items.NETHERITE_INGOT);
        } else if (roll < 9990) { // 0.4% upgrade template
            reward = new ItemStack(Items.NETHERITE_UPGRADE_SMITHING_TEMPLATE);
        } else { // 0.1% jackpot
            Item[] items = {Items.NETHERITE_SWORD, Items.NETHERITE_PICKAXE,
                Items.NETHERITE_CHESTPLATE, Items.NETHERITE_LEGGINGS,
                Items.NETHERITE_BOOTS, Items.ENCHANTED_GOLDEN_APPLE};
            reward = new ItemStack(items[world.random.nextInt(items.length)]);
        }

        if (!player.getInventory().insertStack(reward)) player.dropItem(reward, false);
    }


private static void addRandomEnchantment(World world, ItemStack book) {
    var registry = world.getRegistryManager().get(RegistryKeys.ENCHANTMENT);
    if (registry == null) return;

    var entries = registry.streamEntries().toList();
    if (entries.isEmpty()) return;

    RegistryEntry<Enchantment> enchantment =
        entries.get(world.random.nextInt(entries.size()));

    int maxLevel = Math.max(1, enchantment.value().getMaxLevel());
    int level = 1 + world.random.nextInt(maxLevel);

    EnchantmentHelper.apply(book, builder -> builder.add(enchantment, level));
}
